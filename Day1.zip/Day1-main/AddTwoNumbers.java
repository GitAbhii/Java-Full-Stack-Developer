//sum of two numbers
public class AddTwoNumbers {

    public static void main(String[] args) {
        int a = 10;
        int b = 50;
        System.out.println("Sum = " + (a+b));
    }
}
