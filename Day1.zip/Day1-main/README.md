# Day 1 - Java Basics
## Topics Covered
- Java Introduction
- JDK, JRE, JVM
- Variables
- Data Types

## Programs
1. Add Two Numbers
2. Swap Two Numbers
3. Simple Interest

## Learnings
- How Java program runs
- How to use variables and data types
- Writing simple Java programs
