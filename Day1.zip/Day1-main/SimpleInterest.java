public class  SimpleInterest{

    public static void main(String[] args) {
        int p=1000;
        int r = 10;
        int t = 30;
        int si = (p*r*t)/100;
        System.out.println("simple interest = " + si);
    }
}
